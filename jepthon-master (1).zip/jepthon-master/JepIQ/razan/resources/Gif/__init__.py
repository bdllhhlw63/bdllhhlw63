from ._gif import *
# by ~ @RR7PP
